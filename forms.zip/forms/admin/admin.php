<html>
<head>
    <title>LOGIN</title>
</head>
<body>
<form action="login.php" method="post">
            <label for ="name"> Username: </label>
            <input type ="name" id ="name" name ="username" required><br><br>
            <label for ="password"> Password: </label>
            <input type = "password" id ="password" name = "password"><br><br>
            <input type = "submit" value = "login">
    </body>
    </html>